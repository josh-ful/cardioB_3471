package UserInterface.addExercise;

public class ExerciseLogHelperSQL extends ExerciseLogHelper {
    public ExerciseLogHelperSQL() {
        super();
    }


}

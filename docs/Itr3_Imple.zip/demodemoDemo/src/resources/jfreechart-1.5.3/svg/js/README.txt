JavaScript Utilities
--------------------

This directory contains some JavaScript utility code that can be used when exporting charts to SVG format with JFreeSVG.  The build.sh script will build the library, but note that it requires the Google Closure Compiler jar file to be on the classpath (please edit the script accordingly).

https://developers.google.com/closure/compiler/

Look in the '???' directory (open ???.html) to see a demo that uses this JavaScript code.

package UserInterface;

public enum MetricTypes {
    WEIGHT, SLEEP, CALORIES, WORKOUT
}

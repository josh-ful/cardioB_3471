package UserInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import UserInformation.CurrentUser;

public class GoalsDialog extends JDialog {
    private final JTextField weightField   = new JTextField(6);
    private final JTextField sleepField    = new JTextField(6);
    private final JTextField caloriesField = new JTextField(6);
    private final JTextField workoutField  = new JTextField(6);

    public GoalsDialog(Frame owner) {
        super(owner, "Set Your Weekly Goals", true);
        setLayout(new BorderLayout(10,10));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // preload current goals
        weightField.setText(String.valueOf(CurrentUser.getWeightGoal()));
        sleepField.setText(String.valueOf(CurrentUser.getAvgSleepGoal()));
        caloriesField.setText(String.valueOf(CurrentUser.getAvgCaloriesGoal()));
        workoutField.setText(String.valueOf(CurrentUser.getAvgWorkoutGoal()));

        JPanel grid = new JPanel(new GridLayout(4,2,10,10));
        grid.add(new JLabel("Weight (lbs):"));
        grid.add(weightField);
        grid.add(new JLabel("Sleep (hrs/day):"));
        grid.add(sleepField);
        grid.add(new JLabel("Calories/day:"));
        grid.add(caloriesField);
        grid.add(new JLabel("Workout (min/day):"));
        grid.add(workoutField);

        add(grid, BorderLayout.CENTER);

        JButton save = new JButton("Save");
        save.addActionListener(this::onSave);
        add(save, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(owner);
    }

    private void onSave(ActionEvent e) {
        try {
            CurrentUser.setWeightGoal(Double.parseDouble(weightField.getText()));
            CurrentUser.setAvgSleepGoal(Double.parseDouble(sleepField.getText()));
            CurrentUser.setAvgCaloriesGoal(Double.parseDouble(caloriesField.getText()));
            CurrentUser.setAvgWorkoutGoal(Double.parseDouble(workoutField.getText()));
            dispose();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter valid numbers for all goals.",
                    "Invalid input",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}

package UserInterface.addExercise;


// TODO: implement backend stuff for exerciseLogHelperSQL
public class ExerciseLogHelperSQL extends ExerciseLogHelper {
    public ExerciseLogHelperSQL() {
        super();
    }


}

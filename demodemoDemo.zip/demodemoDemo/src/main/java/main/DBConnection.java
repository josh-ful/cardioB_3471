package main;

import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;
import static main.DatabaseInfo.*;
/*
 * this class represents a DBConnection object
 * which implements the DatabaseInfo interface
 */
public class DBConnection implements DatabaseInfo {
    private static  String URL;
    private static final String USER = "fitnessuser";
    private static final String PASSWORD = "strongpassword123";
    private static Connection conn;

    /**
     * establishes connection to the port
     *
     * @param port id
     */
    public DBConnection(String port) {
        states.put("SQL", true);
        URL = "jdbc:mysql://localhost:" + port + "/fitnessdb";
//        System.out.println(URL);
        try {
            // Explicitly load MySQL JDBC driver clearly
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Now, connect clearly
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            if (conn != null) {
                System.out.println("✅ Connected to MySQL successfully!");
            }
            else {
                System.out.println("Connection failed!");
            }

            //TESTING ADDING USERS ✅
            //String insertSql = "INSERT INTO users (username, password) VALUES (?, ?)";
            //PreparedStatement ps = conn.prepareStatement(insertSql);
            //addUser(ps, "alice", "password1");
            //addUser(ps, "bob", "password2");
            //addUser(ps, "charlie", "password3");


            //CHECK CONNECTION TO RIGHT DATABASE (LIST USERS/HASHED PASSWORDS)
            String sql = "SELECT username FROM users";
            PreparedStatement ps2 = conn.prepareStatement(sql);
            ResultSet rs = ps2.executeQuery();
            while (rs.next()) {
//                System.out.println("Username: " + rs.getString("username"));
                //System.out.println("Password: " + rs.getString("password"));
            }
            String sql2 = "SELECT password FROM users";
            PreparedStatement ps3 = conn.prepareStatement(sql2);
            ResultSet rs2 = ps3.executeQuery();
            while (rs2.next()) {
//                System.out.println("Password: " + rs2.getString("password"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * Creates DBConnection object
     *
     *
     */
    public DBConnection() {
    }
    /**
     * adds user
     *
     * @param ps PreparedStatement ps
     * @param username string username
     * @param plainPassword string normal text password
     */
    public static void addUser(PreparedStatement ps, String username, String plainPassword, String type) throws SQLException {
        String hashed = BCrypt.hashpw(plainPassword, BCrypt.gensalt());
        ps.setString(1, username);
        ps.setString(2, hashed);
        ps.setString(3, type);
        //ps.executeUpdate();
    }
    /**
     * gets connection
     *
     * @return Connection
     */
    public static Connection getConnection() {
        try {
            if (conn.isClosed()) {
                System.out.println("Connection closed!");
                conn = DriverManager.getConnection(URL, USER, PASSWORD);
            }
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Connection doesn't exist!");
        }
        return null;
    }

}

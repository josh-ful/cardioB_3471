package Controller;

import javax.swing.*;
import java.awt.*;

/*
 * this interface serves as the controller
 */
public interface Controller {

    public void createDashboard(JFrame frame);

}

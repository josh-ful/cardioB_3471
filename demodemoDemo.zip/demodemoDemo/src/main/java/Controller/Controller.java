package Controller;
/*
 * this interface serves as the controller
 */
public interface Controller {
}

package Controller;
/*
 * this class serves as the admin user type controller
 */
public class AdminController implements Controller{
}

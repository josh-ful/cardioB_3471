package Controller;
/*
* this class serves as the trainer user type controller
*/
public class TrainerController implements Controller{
}

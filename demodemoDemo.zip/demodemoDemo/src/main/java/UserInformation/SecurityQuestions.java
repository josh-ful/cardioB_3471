package UserInformation;

public class SecurityQuestions {
    public final static String[] securityQuestions = {"What is the name of your first pet?",
            "What is your mother's maiden name?",
            "What was the name of your elementary school?",
            "What was the model of your first car?",
            "What was the name of the street you grew up on?"};
}
